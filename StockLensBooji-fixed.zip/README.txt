StockLensBooji — ไฟล์ที่แก้ไขแล้ว

โครงสร้างไฟล์สำหรับนำขึ้น Vercel:
  index.html
  script.js
  api/analyze.js
  package.json

สิ่งที่แก้:
- เปลี่ยน Gemini model จาก gemini-1.5-flash เป็น gemini-3.8-flash
- เปลี่ยน REST endpoint จาก v1 เป็น v1beta ตามเอกสาร Gemini API
- ส่ง API key ผ่าน x-goog-api-key จากฝั่ง server ไม่ใส่ในหน้าเว็บ
- เพิ่มการจัดการข้อผิดพลาดและการตอบกลับที่ไม่มี candidate
- แยก JavaScript หน้าเว็บเป็น script.js และลบแท็กปิด body/html ที่ซ้ำ
- Escape ข้อความจากโมเดลก่อนนำไปแสดงผล

วิธีนำขึ้น Vercel:
1. นำไฟล์ทั้งหมดใน ZIP ไปไว้ใน root ของโปรเจกต์
2. ตรวจให้แน่ใจว่า backend อยู่ที่ api/analyze.js (ห้ามวาง analyze.js ไว้ root อย่างเดียว)
3. ไปที่ Vercel Project > Settings > Environment Variables
4. เพิ่มตัวแปร GEMINI_API_KEY และใส่ API key จาก Google AI Studio
5. เลือก Environment ที่ใช้งาน (เช่น Production) แล้ว Save
6. ไปที่ Deployments แล้ว Redeploy โปรเจกต์
7. ทดสอบเว็บและกด “ส่องหุ้นเลย!”

หมายเหตุ:
- อย่าใส่ API key จริงใน index.html หรือ script.js
- Gemini ไม่ได้เชื่อมต่อฐานข้อมูลราคาหุ้นแบบเรียลไทม์โดยอัตโนมัติ ผลวิเคราะห์จึงอาจไม่มีราคาล่าสุดที่ยืนยันได้
